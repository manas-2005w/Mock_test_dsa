#include <iostream>
using namespace std;

class Node {
public:
    int value;
    Node* next;
    Node(int val) : value(val), next(nullptr) {}
};

// yeh hum use karte hai to detect the cycle, ek slow ptr jo ek ek step chalega, and ek fast ptr jo two step
Node* detectCycle(Node* head) {
    Node* slow = head;
    Node* fast = head;

   
    while (fast != nullptr && fast->next != nullptr) {
        slow = slow->next;         
        fast = fast->next->next;    
// yaha we check agar slow and fast meets at one point, then the cycle exists 
        if (slow == fast) { 
            
            slow = head;
            while (slow != fast) {
                slow = slow->next;
                fast = fast->next;
            }
            return slow;  
        }
    }
    // no cycle
    return nullptr;  
}

// we use this to remove the cycle
void removeCycle(Node* head) {
    Node* cycleNode = detectCycle(head);
    if (!cycleNode) {
        return;  
    }

    
    Node* prev = cycleNode;
    while (prev->next != cycleNode) {
        prev = prev->next;
    }

    // we change the last node of the linkedlist to null
    prev->next = nullptr;
}

int main() {
    // making of the linkedlist 
    Node* head = new Node(1);
    head->next = new Node(2);
    head->next->next = new Node(3);
    head->next->next->next = new Node(4);
    head->next->next->next->next = head; 

    
    Node* cycleStart = detectCycle(head);
    if (cycleStart) {
        cout << "Cycle starts at node with value: " << cycleStart->value << endl;
    } else {
        cout << "No cycle detected" << endl;
    }

//   calling the function
    removeCycle(head);

    cycleStart = detectCycle(head);
    if (cycleStart) {
        cout << "Cycle still exists, starts at node with value: " << cycleStart->value << endl;
    } else {
        cout << "Cycle removed successfully" << endl;
    }

    return 0;
}
